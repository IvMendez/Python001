from time import sleep
from clases.Empleado import Empleado
from clases.Programador import Programador
from clases.Analista import Analista
from clases.Scrum_master import Scrum_master
from clases.Sistemas_nominas import Sistema_nominas
"""""
Nuestro programa funciona de la siguiente forma, preguntamos al usuario si quiere añadir algun empleado de ser que si
pedimos el nombre y su puesto de trabajo,creamos un empleado con esos datos y segun su puesto de trabajo 
aplicamos la funcion calcular_salario para crear un empleado de la clase del puesto correspondiente y lo añadimos a una
lista,cuando ya no queramos añadir mas empleados pasamos la lista por la funcion de calcular nominas lo que coje en funcion
del puesto de trabajo del empleado, su nombre lo que va a cobrar y los extras por los que cobra, durante el proyecto se ha
usado sleep() para realizar una serie de pausas que mejoran la experiencia de lectura del proyecto
"""
if __name__ == '__main__':
    empleados = []
    while True:
        res = input("Quieres añadir empleados? (s/n) ")
        if res.upper() == "S":
            nombre = input("Indica el nombre del empleado : ")
            puesto = input("Indica su puesto de trabajo: (programador, analista, scrum-master)")
            empleado = Empleado(nombre, puesto)
            if puesto.upper() == "PROGRAMADOR":
                lenguaje = input(f"En que lenguaje trabaja {empleado.nombre}? (Python, Java, JavaScript)")
                programador = Programador(nombre,puesto,lenguaje, empleado.calcular_salario())
                empleados.append(programador)
            if puesto.upper() == "ANALISTA":
                proyectos = int(input(f"Cuantos proyectos ha realizado {empleado.nombre}? (1-3) "))
                analista = Analista(nombre,puesto,proyectos, empleado.calcular_salario())
                empleados.append(analista)
            if puesto.upper() == "SCRUM-MASTER":
                sesiones_realizadas = int(input(f"Cuantas sesiones ha realizado {empleado.nombre}? (1-3) "))
                scrum_master = Scrum_master(nombre,puesto,sesiones_realizadas, empleado.calcular_salario())
                empleados.append(scrum_master)
        if res.upper() == "N":
            print("Vamos a calcular sus nominas")
            sleep(1)
            break
    iniciar = Sistema_nominas()
    iniciar.calcular_nominas(empleados)