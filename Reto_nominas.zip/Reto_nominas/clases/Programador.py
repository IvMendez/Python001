from clases.Empleado import Empleado
class Programador(Empleado):
    def __init__(self, nombre, puesto, lenguaje, salario):
        super().__init__(nombre, puesto)
        self.lenguaje=lenguaje
        self.salario = salario
    def calcular_salarioT(self):
        if self.lenguaje.upper() == "PYTHON":
            return self.salario*1.1
        if self.lenguaje.upper() == "JAVA":
            return self.salario*1.2
        if self.lenguaje.upper() == "JAVASCRIPT":
            return self.salario*1.05