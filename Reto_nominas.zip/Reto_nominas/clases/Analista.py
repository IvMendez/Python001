from clases.Empleado import Empleado
class Analista(Empleado):
    def __init__(self, nombre, puesto, proyectos, salario):
        super().__init__(nombre, puesto)
        self.proyectos=proyectos
        self.salario = salario
    def calcular_salarioT(self):
        if self.proyectos == 1:
            return self.salario*1.1
        if self.proyectos == 2:
            return self.salario*1.2
        if self.proyectos == 3:
            return self.salario*1.3