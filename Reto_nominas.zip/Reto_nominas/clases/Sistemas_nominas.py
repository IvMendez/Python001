from time import sleep
class Sistema_nominas:
    def __init__(self):
        x = 0
    def calcular_nominas(self, empleados):
        print("            Calculando nominas            ")
        print("==========================================")
        sleep(2)
        for empleado in empleados:
            if empleado.puesto.upper() == "PROGRAMADOR":
                print(f"Nomina para : {empleado.nombre} - {empleado.lenguaje}")
                print(f"{empleado.calcular_salarioT()}")
                print()
                sleep(1)
            if empleado.puesto.upper() == "ANALISTA":
                print(f"Nomina para : {empleado.nombre} - que ha realizado {empleado.proyectos} proyectos")
                print(f"{empleado.calcular_salarioT()}")
                print()
                sleep(1)
            if empleado.puesto.upper() == "SCRUM-MASTER":
                print(f"Nomina para : {empleado.nombre} - que ha realizado {empleado.sesiones_realizadas} sesiones")
                print(f"{empleado.calcular_salarioT()}")
                print()
                sleep(1)

            
    
