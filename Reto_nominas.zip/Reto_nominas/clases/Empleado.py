class Empleado:
    def __init__(self, nombre, puesto):
        self.nombre = nombre
        self.puesto = puesto
    def calcular_salario(self):
        global x
        x = 0
        if self.puesto.upper() == "PROGRAMADOR":
            x = 1200
        if self.puesto.upper() == "ANALISTA":
            x = 1100
        if self.puesto.upper() == "SCRUM_MASTER":
            x = 1150
        return x
